package br.edu.iff.a2.a2016.petapp;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static br.edu.iff.a2.a2016.petapp.R.id.activity_login;

public class login extends Activity {

    private Button CAD, enviar;
    private EditText US;
    private EditText Senha;


    @Override



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        US = (EditText) findViewById(R.id.user);

        Senha = (EditText) findViewById(R.id.senha) ;

        CAD = (Button) findViewById(R.id.cadastrar);


        CAD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent tela = new Intent(login.this, cadastroPessoa.class);
                startActivity(tela);
                finish();

            }


        });

        enviar = (Button) findViewById(R.id.login);


        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String logincerto ="Robertaarg";
                String senhacerta ="1234";
                String struser = US.getText().toString();
               String stsenha = Senha.getText().toString();

                if (struser.equals(logincerto) && stsenha.equals(senhacerta)) {

                    Intent tela = new Intent(login.this, menu.class);
                    startActivity(tela);
                    finish();
                }else {
                    Toast.makeText(login.this, "Senha ou usuário inválido",Toast.LENGTH_LONG).show();
                }
            }


        });





    }
}
