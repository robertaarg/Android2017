package br.edu.iff.a2.a2016.petapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cadastroPessoa extends AppCompatActivity {

    private Button PROX,voltar;
    private EditText nome,tel,rua,numero,bairro,user,senha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_pessoa);

        nome = (EditText) findViewById(R.id.nome);
        tel = (EditText) findViewById(R.id.tel);
        rua = (EditText) findViewById(R.id.rua);
        numero = (EditText) findViewById(R.id.num);
        bairro = (EditText) findViewById(R.id.bairro);
        user = (EditText) findViewById(R.id.user);
        senha = (EditText) findViewById(R.id.senha);
        PROX = (Button) findViewById(R.id.proximo);

        voltar = (Button) findViewById(R.id.Volta);


        PROX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String N = nome.getText().toString();
                String T = tel.getText().toString();
                String Ru = rua.getText().toString();
                String NU = numero.getText().toString();
                String B = bairro.getText().toString();
                String S = senha.getText().toString();
                String U = user.getText().toString();


                if ( N.isEmpty() && T.isEmpty() && Ru.isEmpty() && NU.isEmpty() && B.isEmpty() && S.isEmpty() && U.isEmpty())  {

                    Toast.makeText(cadastroPessoa.this, "Preencha todos os campos",Toast.LENGTH_LONG).show();
                } else{

                    Toast.makeText(cadastroPessoa.this, "Cadastro efetuado",Toast.LENGTH_LONG).show();

                    Intent tela = new Intent(cadastroPessoa.this, cadastroPet.class);
                    startActivity(tela);
                    finish();
            }
            }


        });

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {





                Intent tela = new Intent(cadastroPessoa.this, login.class);
                startActivity(tela);
                finish();

            }


        });


    }
}
