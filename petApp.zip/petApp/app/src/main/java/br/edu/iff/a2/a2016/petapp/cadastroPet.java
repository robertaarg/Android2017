package br.edu.iff.a2.a2016.petapp;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cadastroPet extends AppCompatActivity {

    private Button PROX2;
    private EditText NomePet,Peso,Porte,Obs;
    private SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_pet);

        bancoDados = openOrCreateDatabase("Banco", MODE_PRIVATE, null);

        bancoDados.execSQL("CREATE TABLE IF NOT EXISTS pets(nomePet VARCHAR PRIMARY KEY, peso VARCHAR, porte VARCHAR, obs VARCHAR ) ");

        PROX2 = (Button) findViewById(R.id.pro2);

        NomePet = (EditText) findViewById(R.id.nomePet);
        Peso = (EditText) findViewById(R.id.peso);
        Porte = (EditText) findViewById(R.id.Prote);
        Obs = (EditText) findViewById(R.id.obs);

        PROX2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String NP = NomePet.getText().toString();
                String P = Peso.getText().toString();
                String PO = Porte.getText().toString();
                String O = Obs.getText().toString();

                if ( NP.isEmpty() && P.isEmpty() && PO.isEmpty() && O.isEmpty() ) {

                    Toast.makeText(cadastroPet.this, "Preencha todos os campos", Toast.LENGTH_LONG).show();


                } else {
                    salvarPet( NP,P,PO,O);




                    Intent tela = new Intent(cadastroPet.this, servicos.class);
                    startActivity(tela);
                    finish();

                }

            }


        });
    }

        private void salvarPet(String NP,String P, String PO, String O ){

            try{


                    bancoDados.execSQL("INSERT INTO pets (nomePet,peso,porte,obs) VALUES('" + NP +P+PO+O+')');
                    Toast.makeText(cadastroPet.this, "Tarefa salva com sucesso!", Toast.LENGTH_SHORT).show();



            }catch(Exception e){
                e.printStackTrace();
            }
        }







}
