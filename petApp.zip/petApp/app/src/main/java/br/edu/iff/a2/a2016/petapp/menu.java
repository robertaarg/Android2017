package br.edu.iff.a2.a2016.petapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class menu extends AppCompatActivity {


    private Button MA,SEV,Alterarpet,sair;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        MA= (Button) findViewById(R.id.ma);

        MA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent tela = new Intent(menu.this, Agenda.class);
                startActivity(tela);
                finish();

            }

        });

        SEV= (Button) findViewById(R.id.serv);

        SEV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent tela = new Intent(menu.this, servicos.class);
                startActivity(tela);
                finish();

            }

        });


        sair= (Button) findViewById(R.id.Sair);

        sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent tela = new Intent(menu.this, login.class);
                startActivity(tela);
                finish();

            }

        });

    }
}
